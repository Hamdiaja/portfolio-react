import React, { useEffect } from 'react';
import { ThemeProvider } from './contexts/ThemeContext';
import { LanguageProvider } from './contexts/LanguageContext';

// Import Sections
import Hero from './components/Sections/Hero';
import About from './components/Sections/About';
import Skills from './components/Sections/Skills';
import Projects from './components/Sections/Projects';
import Experience from './components/Sections/Experience';
import Contact from './components/Sections/Contact';

// Import Layout
import Footer from './components/Layout/Footer';

// Import UI Components
import FloatingActionButton from './components/UI/FloatingActionButton';

// Import Styles
import './styles/index.css';

function App() {
    // Keyboard shortcuts - exact same as vanilla version
    useEffect(() => {
        const handleKeyDown = (e) => {
            const activeElement = document.activeElement;
            const isTyping = activeElement.tagName === 'INPUT' || activeElement.tagName === 'TEXTAREA';
            
            if (isTyping) return;

            switch (e.key.toLowerCase()) {
                case 'm':
                    // Toggle menu - will be handled by FAB component
                    document.querySelector('.fab-main')?.click();
                    break;
                case 't':
                    // Toggle theme - will be handled by FAB component  
                    document.querySelector('.fab-option[title="Toggle Theme"]')?.click();
                    break;
                case 'l':
                    // Toggle language - will be handled by FAB component
                    document.querySelector('.fab-option[title="Language"]')?.click();
                    break;
                default:
                    break;
            }
        };

        document.addEventListener('keydown', handleKeyDown);
        return () => document.removeEventListener('keydown', handleKeyDown);
    }, []);

    return (
        <ThemeProvider>
            <LanguageProvider>
                <div className="App">
                    {/* Floating Action Button */}
                    <FloatingActionButton />
                    
                    {/* Main Content */}
                    <main className="main-content">
                        <Hero />
                        <About />
                        <Skills />
                        <Projects />
                        <Experience />
                        <Contact />
                    </main>
                    
                    {/* Footer */}
                    <Footer />
                </div>
            </LanguageProvider>
        </ThemeProvider>
    );
}

export default App;