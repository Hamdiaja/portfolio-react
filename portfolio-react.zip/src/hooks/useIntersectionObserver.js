import { useEffect, useRef } from 'react';

export const useIntersectionObserver = (callback, options = {}) => {
    const targetRef = useRef(null);

    useEffect(() => {
        const target = targetRef.current;
        if (!target) return;

        const defaultOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px',
            ...options
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                callback(entry);
            });
        }, defaultOptions);

        observer.observe(target);

        return () => {
            if (target) {
                observer.unobserve(target);
            }
        };
    }, [callback, options]);

    return targetRef;
};