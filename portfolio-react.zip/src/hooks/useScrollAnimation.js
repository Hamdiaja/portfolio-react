import { useEffect } from 'react';
import { useIntersectionObserver } from './useIntersectionObserver';

export const useScrollAnimation = () => {
    const sectionRef = useIntersectionObserver((entry) => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });

    useEffect(() => {
        const element = sectionRef.current;
        if (element) {
            element.style.opacity = '0';
            element.style.transform = 'translateY(30px)';
            element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        }
    }, []);

    return sectionRef;
};