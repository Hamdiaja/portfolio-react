import React from 'react';
import { useScrollAnimation } from '../../hooks/useScrollAnimation';

const AnimatedSection = ({ children, ...props }) => {
    const sectionRef = useScrollAnimation();

    return (
        <div ref={sectionRef} {...props}>
            {children}
        </div>
    );
};

export default AnimatedSection;