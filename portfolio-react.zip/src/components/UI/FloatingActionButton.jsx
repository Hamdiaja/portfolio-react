import React, { useState, useEffect } from 'react';
import { Menu, X, User, Linkedin, Sun, Moon } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';
import { useLanguage } from '../../contexts/LanguageContext';
import { portfolioData } from '../../data/portfolioData';

const FloatingActionButton = () => {
    const [isOpen, setIsOpen] = useState(false);
    const { isDark, toggleTheme } = useTheme();
    const { currentLang, toggleLanguage } = useLanguage();

    const toggleFAB = () => {
        setIsOpen(prev => !prev);
    };

    const handleAboutClick = () => {
        const aboutSection = document.getElementById('about');
        if (aboutSection) {
            aboutSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        setIsOpen(false);
    };

    const handleLinkedInClick = () => {
        const linkedinUrl = portfolioData.personal.linkedin;
        if (linkedinUrl !== '[LinkedIn URL]') {
            window.open(linkedinUrl, '_blank', 'noopener,noreferrer');
        } else {
            alert('Please update your LinkedIn URL in portfolioData.js');
        }
        setIsOpen(false);
    };

    const handleThemeToggle = () => {
        toggleTheme();
        setIsOpen(false);
    };

    const handleLanguageToggle = () => {
        toggleLanguage();
        setIsOpen(false);
    };

    // Close FAB when clicking outside
    useEffect(() => {
        const handleClickOutside = (e) => {
            if (!e.target.closest('.floating-menu') && isOpen) {
                setIsOpen(false);
            }
        };

        document.addEventListener('click', handleClickOutside);
        return () => document.removeEventListener('click', handleClickOutside);
    }, [isOpen]);

    return (
        <div className="floating-menu">
            <button 
                className={`fab-main ${isOpen ? 'active' : ''}`}
                onClick={toggleFAB}
                aria-label="Toggle menu"
            >
                {isOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
            
            <div className={`fab-options ${isOpen ? 'show' : ''}`}>
                <button 
                    className="fab-option" 
                    onClick={handleAboutClick}
                    title="About"
                    aria-label="About"
                >
                    <User size={16} />
                </button>
                
                <button 
                    className="fab-option" 
                    onClick={handleLinkedInClick}
                    title="LinkedIn"
                    aria-label="LinkedIn"
                >
                    <Linkedin size={16} />
                </button>
                
                <button 
                    className="fab-option" 
                    onClick={handleThemeToggle}
                    title="Toggle Theme"
                    aria-label="Toggle Theme"
                >
                    {isDark ? <Moon size={16} /> : <Sun size={16} />}
                </button>
                
                <button 
                    className="fab-option" 
                    onClick={handleLanguageToggle}
                    title="Language"
                    aria-label="Toggle Language"
                >
                    <span className="lang-text">{currentLang.toUpperCase()}</span>
                </button>
            </div>
        </div>
    );
};

export default FloatingActionButton;