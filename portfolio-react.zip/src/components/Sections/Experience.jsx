import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { portfolioData } from '../../data/portfolioData';

const ExperienceItem = ({ experience }) => {
    const { currentLang } = useLanguage();

    return (
        <div className="timeline-item">
            <div className="timeline-date">{experience.period}</div>
            <div className="timeline-content">
                <h3 className="timeline-title">
                    {experience.position} at {experience.company}
                </h3>
                <p className="timeline-description">
                    {experience.description[currentLang]}
                </p>
                <div className="timeline-tech">
                    {experience.technologies.map((tech, index) => (
                        <span key={index} className="tech-tag">{tech}</span>
                    ))}
                </div>
            </div>
        </div>
    );
};

const Experience = () => {
    const { t } = useLanguage();

    return (
        <section id="experience" className="experience">
            <div className="container">
                <h2 className="section-title">
                    {t('Experience', 'Pengalaman')}
                </h2>
                <div className="timeline">
                    {portfolioData.experience.map((exp) => (
                        <ExperienceItem key={exp.id} experience={exp} />
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Experience;