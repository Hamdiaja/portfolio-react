import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { portfolioData } from '../../data/portfolioData';

const Hero = () => {
    const { t } = useLanguage();

    return (
        <AnimatedSection>
        <section id="home" className="hero">
            <div className="container">
                <div className="hero-content">
                    <div className="hero-text">
                        <h1 className="hero-title">
                            {t(
                                `Hi, I'm ${portfolioData.personal.name} 👋`,
                                `Hai, Saya ${portfolioData.personal.name} 👋`
                            )}
                        </h1>
                        <div className="hero-avatar">
                            <div className="avatar-placeholder">
                                {portfolioData.personal.initials}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
      </AnimatedSection>  
    );
};

export default Hero;