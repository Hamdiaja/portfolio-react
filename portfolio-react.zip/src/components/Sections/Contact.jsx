import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { portfolioData } from '../../data/portfolioData';

const Contact = () => {
    const { t } = useLanguage();

    const handleEmailClick = (e) => {
        const email = portfolioData.personal.email;
        if (navigator.clipboard && email !== '[email@domain.com]') {
            e.preventDefault();
            navigator.clipboard.writeText(email.replace('mailto:', '')).then(() => {
                // Create notification
                const notification = document.createElement('div');
                notification.textContent = t('Email copied to clipboard!', 'Email disalin ke clipboard!');
                notification.style.cssText = `
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background-color: var(--accent-color);
                    color: var(--bg-primary);
                    padding: 12px 20px;
                    border-radius: 8px;
                    font-weight: 500;
                    z-index: 10000;
                    animation: slideIn 0.3s ease;
                `;
                
                document.body.appendChild(notification);
                setTimeout(() => notification.remove(), 3000);
            });
        }
    };

    return (
        <section id="contact" className="contact">
            <div className="container">
                <h2 className="section-title">
                    {t('Contact', 'Kontak')}
                </h2>
                <div className="contact-content">
                    <h3 className="contact-subtitle">
                        {t('Get in Touch', 'Mari Terhubung')}
                    </h3>
                    <p className="contact-description">
                        {t('Want to chat? Just shoot me a dm ', 'Ingin ngobrol? Kirimkan saya pesan ')}
                        <a href={portfolioData.personal.linkedin} className="contact-link">
                            {t('with a direct question', 'dengan pertanyaan langsung')}
                        </a>
                        {t(' and I\'ll respond whenever I can. I will ignore all soliciting.', ' dan saya akan merespons kapan pun saya bisa. Saya akan mengabaikan semua penawaran.')}
                    </p>
                    
                    <div className="contact-links">
                        <a 
                            href={`mailto:${portfolioData.personal.email}`} 
                            className="contact-item"
                            onClick={handleEmailClick}
                        >
                            <span className="contact-icon">📧</span>
                            <span className="contact-text">{portfolioData.personal.email}</span>
                        </a>
                        <a 
                            href={portfolioData.personal.linkedin} 
                            className="contact-item" 
                            target="_blank" 
                            rel="noopener noreferrer"
                        >
                            <span className="contact-icon">💼</span>
                            <span className="contact-text">LinkedIn</span>
                        </a>
                        <a 
                            href={portfolioData.personal.github} 
                            className="contact-item" 
                            target="_blank" 
                            rel="noopener noreferrer"
                        >
                            <span className="contact-icon">🐙</span>
                            <span className="contact-text">GitHub</span>
                        </a>
                        <a 
                            href={portfolioData.personal.twitter} 
                            className="contact-item" 
                            target="_blank" 
                            rel="noopener noreferrer"
                        >
                            <span className="contact-icon">🐦</span>
                            <span className="contact-text">Twitter</span>
                        </a>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Contact;