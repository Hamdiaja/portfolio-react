import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { portfolioData } from '../../data/portfolioData';

const ProjectCard = ({ project }) => {
    const { t, currentLang } = useLanguage();

    return (
        <div className="project-card">
            <div className="project-image">
                <div className="project-placeholder">
                    {t('Project Image', 'Gambar Proyek')}
                </div>
            </div>
            <div className="project-content">
                <h3 className="project-title">{project.title}</h3>
                <p className="project-description">
                    {project.description[currentLang]}
                </p>
                <div className="project-tech">
                    {project.technologies.map((tech, index) => (
                        <span key={index} className="tech-tag">{tech}</span>
                    ))}
                </div>
                <div className="project-links">
                    <a href={project.liveDemo} className="project-link">
                        {t('Live Demo', 'Demo Langsung')}
                    </a>
                    <a href={project.sourceCode} className="project-link">
                        {t('Source Code', 'Kode Sumber')}
                    </a>
                </div>
            </div>
        </div>
    );
};

const Projects = () => {
    const { t } = useLanguage();

    return (
        <section id="projects" className="projects">
            <div className="container">
                <h2 className="section-title">
                    {t('Projects', 'Proyek')}
                </h2>
                <div className="projects-grid">
                    {portfolioData.projects.map((project) => (
                        <ProjectCard key={project.id} project={project} />
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Projects;