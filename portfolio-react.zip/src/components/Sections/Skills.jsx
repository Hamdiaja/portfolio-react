import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { portfolioData } from '../../data/portfolioData';

const Skills = () => {
    const { t } = useLanguage();

    const categoryTranslations = {
        'Programming Languages': 'Bahasa Pemrograman',
        'Frameworks': 'Framework',
        'Tools & Technologies': 'Tools & Teknologi',
        'Databases': 'Database'
    };

    return (
        <section id="skills" className="skills">
            <div className="container">
                <h2 className="section-title">
                    {t('Skills', 'Keahlian')}
                </h2>
                <div className="skills-grid">
                    {Object.entries(portfolioData.skills).map(([category, skills]) => (
                        <div key={category} className="skill-category">
                            <h3 className="skill-category-title">
                                {t(category, categoryTranslations[category] || category)}
                            </h3>
                            <div className="skill-tags">
                                {skills.map((skill, index) => (
                                    <span key={index} className="skill-tag">
                                        {skill}
                                    </span>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default Skills;