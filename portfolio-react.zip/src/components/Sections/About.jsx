import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { portfolioData } from '../../data/portfolioData';

const About = () => {
    const { t } = useLanguage();

    return (
        <section id="about" className="about">
            <div className="container">
                <h2 className="section-title">
                    {t('About', 'Tentang')}
                </h2>
                <div className="about-content">
                    <p>
                        {t(portfolioData.about.en, portfolioData.about.id)}
                    </p>
                </div>
            </div>
        </section>
    );
};

export default About;