import React from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { portfolioData } from '../../data/portfolioData';

const Footer = () => {
    const { t } = useLanguage();

    return (
        <footer className="footer">
            <div className="container">
                <p>
                    {t(
                        `© 2025 ${portfolioData.personal.name}. All rights reserved.`,
                        `© 2025 ${portfolioData.personal.name}. Hak cipta dilindungi.`
                    )}
                </p>
            </div>
        </footer>
    );
};

export default Footer;