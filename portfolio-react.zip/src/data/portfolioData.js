export const portfolioData = {
    personal: {
        name: "[Your Name]", // Replace with your name
        initials: "[Inisial]", // Replace with your initials
        email: "[email@domain.com]", // Replace with your email
        linkedin: "[LinkedIn URL]", // Replace with your LinkedIn
        github: "[GitHub URL]", // Replace with your GitHub
        twitter: "[Twitter URL]" // Replace with your Twitter
    },
    
    about: {
        en: "[Write about yourself, educational background, work experience, and passion in the field you're engaged in. Tell your career journey briefly and interestingly.]",
        id: "[Tuliskan tentang diri Anda, background pendidikan, pengalaman kerja, dan passion dalam bidang yang Anda geluti. Ceritakan journey karier Anda secara singkat dan menarik.]"
    },
    
    skills: {
        "Programming Languages": [
            "[Language 1]", "[Language 2]", "[Language 3]"
            // Add your actual skills
        ],
        "Frameworks": [
            "[Framework 1]", "[Framework 2]", "[Framework 3]"
            // Add your actual frameworks
        ],
        "Tools & Technologies": [
            "[Tool 1]", "[Tool 2]", "[Tool 3]"
            // Add your actual tools
        ],
        "Databases": [
            "[Database 1]", "[Database 2]", "[Database 3]"
            // Add your actual databases
        ]
    },
    
    projects: [
        {
            id: 1,
            title: "[Project Name]",
            description: {
                en: "[Brief description of the project and technologies used]",
                id: "[Deskripsi singkat project dan teknologi yang digunakan]"
            },
            image: "/images/project1.jpg", // Add your project images
            technologies: ["[Tech 1]", "[Tech 2]", "[Tech 3]"],
            liveDemo: "#",
            sourceCode: "#"
        },
        {
            id: 2,
            title: "[Project Name]",
            description: {
                en: "[Brief description of the project and technologies used]",
                id: "[Deskripsi singkat project dan teknologi yang digunakan]"
            },
            image: "/images/project2.jpg",
            technologies: ["[Tech 1]", "[Tech 2]", "[Tech 3]"],
            liveDemo: "#",
            sourceCode: "#"
        },
        {
            id: 3,
            title: "[Project Name]",
            description: {
                en: "[Brief description of the project and technologies used]",
                id: "[Deskripsi singkat project dan teknologi yang digunakan]"
            },
            image: "/images/project3.jpg",
            technologies: ["[Tech 1]", "[Tech 2]", "[Tech 3]"],
            liveDemo: "#",
            sourceCode: "#"
        }
    ],
    
    experience: [
        {
            id: 1,
            period: "[Year - Year]",
            position: "[Position]",
            company: "[Company]",
            description: {
                en: "[Job description, responsibilities, and achievements]",
                id: "[Deskripsi pekerjaan, tanggung jawab, dan pencapaian]"
            },
            technologies: ["[Tech 1]", "[Tech 2]", "[Tech 3]"]
        },
        {
            id: 2,
            period: "[Year - Year]",
            position: "[Position]",
            company: "[Company]",
            description: {
                en: "[Job description, responsibilities, and achievements]",
                id: "[Deskripsi pekerjaan, tanggung jawab, dan pencapaian]"
            },
            technologies: ["[Tech 1]", "[Tech 2]", "[Tech 3]"]
        },
        {
            id: 3,
            period: "[Year - Year]",
            position: "[Position]",
            company: "[Company]",
            description: {
                en: "[Job description, responsibilities, and achievements]",
                id: "[Deskripsi pekerjaan, tanggung jawab, dan pencapaian]"
            },
            technologies: ["[Tech 1]", "[Tech 2]", "[Tech 3]"]
        }
    ]
};